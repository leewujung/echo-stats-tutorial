function [pdf_x, pdf_y] = prosph_simulation(e_ac)
% Physics based simulation representing a randomly rough, randomly oriented
% prolate spheroid of eccentricity e_ac randomly located in a cylindrical
% aperture beampattern of ka = 2*pi.

% Setting constants
r = 0.1;
c = ((r^3)/(e_ac^2))^(1/3); 
e_ba = 1;

% Generating random variables
theta_sph = rand(1, 5e6)*pi/2;
roughness = raylrnd(ones(1, 5e6)/sqrt(2));

% Calculating echo amplitude
rsa = (((c^2)*(e_ba^2))/4)*((sin(atan(e_ac./tan(theta_sph)))./cos(theta_sph)).^2);

% Multiplying factors
data = rsa.*roughness;

% Binning data
[pdf_x, pdf_y] = logbinner(data, 300, 0);